export interface RegisterPharmacist {
  hospitalIds?: number
  name: string
  email: string
  location: string
  phoneNumber: string
  regNo: string
}
