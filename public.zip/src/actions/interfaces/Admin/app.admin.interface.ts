export interface RegisterAdminArgs {
  name: string
  email: string
  walletAddress: string
}
